//
//  NetDevloopsMastercardGateway.h
//  Ti.MastercardGateway
//
//  Created by Abdullah Al-Faqeir
//  Copyright (c) 2020 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NetDevloopsMastercardGateway.
FOUNDATION_EXPORT double NetDevloopsMastercardGatewayVersionNumber;

//! Project version string for NetDevloopsMastercardGateway.
FOUNDATION_EXPORT const unsigned char NetDevloopsMastercardGatewayVersionString[];

#import "NetDevloopsMastercardGatewayModuleAssets.h"
